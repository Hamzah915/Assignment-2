import UIKit

// dicitonaires
var cities = ["England":"London", "France":"Paris", "Spain":"Madrid"]
print("Dictionary:", cities)

var countries  = Array(cities.keys)
print("Keys: ", countries)

// class inheritance

class Animal {
    var name: String
    var type: String

    init(name: String, type: String) {
        self.name = name
        self.type = type
    }
}

class Lion: Animal {
    init(name: String) {
        super.init(name: name, type: "Lion")
    }
}

// tuples and way of accessing tuples

var laptop = ("Mac", 1400)

print("Name:", laptop.0)
print("Price:", laptop.1)
